# Authors of this project

Original authors of class NocaseDict when it was part of pywbem:

```
Bart Whiteley <bwhiteley@gmail.com>
Karl Schopmeyer <k.schopmeyer@swbell.net>
Karl Schopmeyer <kschopmeyer@inovaserver3.inovadevelopment.com>
Tim Potter <tpot@hp.com>
```

Sorted list of authors derived from git commit history:
```
Andreas Maier <andreas.r.maier@gmx.de>
Andreas Maier <andy-maier@users.noreply.github.com>
```
